-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 17 nov 2024 om 01:04
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `mobilenet`;

USE `mobilenet`;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobilenet`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `brands`
--

CREATE TABLE `brands` (
  `id` int(2) NOT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(1, 'Samsung'),
(2, 'Sony'),
(3, 'Apple'),
(4, 'Huawei'),
(5, 'Nokia'),
(6, 'Wiko'),
(7, 'Honor'),
(8, 'OnePlus'),
(9, 'Xiaomi'),
(10, 'Google');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `operating_systems`
--

CREATE TABLE `operating_systems` (
  `id` int(2) NOT NULL,
  `name` varchar(45) NOT NULL,
  `codename` varchar(45) DEFAULT NULL,
  `release_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `operating_systems`
--

INSERT INTO `operating_systems` (`id`, `name`, `codename`, `release_date`) VALUES
(1, 'iOS 9', '', '2015-09-16'),
(2, 'iOS 10', '', '2016-09-13'),
(3, 'iOS 11', '', '2017-09-19'),
(4, 'iOS 12', '', '2018-09-17'),
(5, 'Android 5.0', 'Lollipop', '2014-11-04'),
(6, 'Android 6.0', 'Marshmallow', '2015-10-02'),
(7, 'Android 7.0', 'Nougat', '2016-08-22'),
(8, 'Android 8.0', 'Oreo', '2017-08-21'),
(9, 'Android 9.0', 'Pie', '2018-08-07'),
(10, 'Windows 8.0', '', '2012-10-29'),
(11, 'Windows 10.0', '', '2015-01-21'),
(12, 'Android 10 Q', NULL, '2019-09-03'),
(13, 'Android 12', NULL, '2021-10-04'),
(14, 'Android 13', 'Tiramisu', '2022-08-15'),
(15, 'Android 14', 'Upside Down Cake', '2023-10-04'),
(16, 'Android 15', 'Vanilla Ice Cream', '2024-09-03'),
(17, 'iOS 17', NULL, '2023-09-18'),
(18, 'iOS 18', NULL, '2024-09-16');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `smartphones`
--

CREATE TABLE `smartphones` (
  `id` int(2) NOT NULL,
  `name` varchar(45) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `stock` int(4) NOT NULL,
  `release_date` date NOT NULL,
  `brand` int(2) NOT NULL,
  `operating_system` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `smartphones`
--

INSERT INTO `smartphones` (`id`, `name`, `price`, `stock`, `release_date`, `brand`, `operating_system`) VALUES
(1, 'Galaxy S10', 899.95, 5, '2019-04-05', 1, 9),
(2, 'Lumia 650', 164.95, 14, '2016-02-15', 5, 11),
(3, 'Xperia 10 Plus', 429.49, 8, '2019-03-15', 2, 9),
(4, 'Xperia XA1', 169.00, 0, '2017-03-31', 2, 7),
(5, 'iPhone X', 949.99, 18, '2017-11-03', 3, 4),
(6, 'Galaxy A6', 189.00, 31, '2016-10-07', 1, 9),
(7, 'Xperia XZ1', 441.12, 6, '2017-08-31', 2, 8),
(8, 'Lumia 950', 89.95, 3, '2015-10-06', 2, 11),
(9, 'iPhone 8', 644.99, 0, '2017-09-22', 3, 2),
(10, 'Mate 20', 481.95, 15, '2018-10-16', 4, 9),
(11, 'iPhone Xs', 1139.29, 12, '2018-09-21', 3, 2),
(12, 'Galaxy S20', 429.00, 17, '2020-03-06', 1, 12),
(13, 'OnePlus Nord 2T', 499.98, 4, '2022-07-01', 8, 13),
(14, 'Galaxy S23 Ultra', 1199.00, 12, '2023-02-17', 1, 14),
(15, 'iPhone 15 Pro', 999.00, 2, '2023-09-22', 3, 17),
(16, 'OnePlus 11', 699.00, 14, '2023-02-07', 8, 14),
(17, 'Galaxy S24 Ultra', 1299.00, 2, '2024-01-31', 1, 15),
(18, 'Pixel 9', 799.00, 0, '2024-08-22', 10, 15);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `operating_systems`
--
ALTER TABLE `operating_systems`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `smartphones`
--
ALTER TABLE `smartphones`
  ADD PRIMARY KEY (`id`,`brand`,`operating_system`),
  ADD KEY `fk_smartphones_brands_idx` (`brand`),
  ADD KEY `fk_smartphones_operating_systems1_idx` (`operating_system`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT voor een tabel `operating_systems`
--
ALTER TABLE `operating_systems`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT voor een tabel `smartphones`
--
ALTER TABLE `smartphones`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `smartphones`
--
ALTER TABLE `smartphones`
  ADD CONSTRAINT `fk_smartphones_brands` FOREIGN KEY (`brand`) REFERENCES `brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_smartphones_operating_systems1` FOREIGN KEY (`operating_system`) REFERENCES `operating_systems` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
