-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `air_travel`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `airports`
--
CREATE DATABASE IF NOT EXISTS `air_travel`;

USE `air_travel`;

CREATE TABLE `airports` (
  `id` varchar(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `airports`
--

INSERT INTO `airports` (`id`, `name`, `country_id`) VALUES
('AMS', 'Amsterdam Airport Schiphol', 5),
('BRU', 'Brussels Airport', 2),
('CDG', 'Paris-Charles de Gaulle Airport', 7),
('CRL', 'Brussels South Charleroi Airport', 2),
('DUS', 'Dusseldorf Airport', 1),
('FRA', 'Frankfurt Airport', 1),
('JFK', 'John F. Kennedy International Airport', 4),
('LCY', 'London City Airport', 3),
('LHR', 'Heathrow Airport', 3),
('SXF', 'Berlin Schenefeld Airport', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `classes`
--

INSERT INTO `classes` (`id`, `name`) VALUES
(1, 'business'),
(2, 'economy');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `countries`
--

INSERT INTO `countries` (`id`, `name`) VALUES
(1, 'Duitsland'),
(2, 'Belgie'),
(3, 'Verenigd Koninkrijk'),
(4, 'Verenigde Staten'),
(5, 'Nederland'),
(6, 'Canada'),
(7, 'Frankrijk');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(62) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `customers`
--

INSERT INTO `customers` (`id`, `last_name`, `first_name`, `email`, `password`) VALUES
(1, 'Johnson', 'Karen', 'karen.johnson@hotmail.com', '$2y$12$Vv9l5tg68TLLrijTLEsQsuj6mreXcVWWvtZS0CzCA7JOtsAqJoHP2'),
(2, 'Van Gent', 'Peter', 'peter.van.gent @gmail.com', '$2y$12$wjFXKMgniv9xsSPc.C/c1u5p2DjH6QOy5O6.aECQ4RU9SRGiD4ZZy'),
(3, 'De Poorter', 'Ari', 'peter.van.gent@telenet.be', '$2y$12$8cdjTZQfNJ2YjTc6f3ZF4OpKUJio3HiWSp8kVIx.etOuA5RDwEZIi'),
(4, 'Aslan', 'Muhammed', 'muhammed.aslan@daily.co.uk', '$2y$12$UagUzQYJR9YoDAIglqA/j.svIGiGiA2vyV.4d5lo0V24MKx522MB2'),
(5, 'Maes', 'Sonja', 'sonja.maes@proximus.be', '$2y$12$gdSDcqQnuwjryw/VaSiqW.OGcshZUwB.VagM6rE7PXHCeiMVRFaKO'),
(6, 'Wilson', 'Sarah', 'sarah.wilson@gmail.com', '$2y$12$agncdCWvU9MPz3jaQBi1E.5qz/mrTOxvN7AOLU7tRw6x5u7lXYJNO'),
(7, 'Miller', 'Danny', 'danny.miller@outlook.com', '$2y$12$r.zzdfnmsZc/0xCMDDErvueDNl63hldbkmU1d0ZYvkr8jKMiUa4RW'),
(8, 'Davis', 'Nelly', 'nelly.davis@hotmail.com', '$2y$12$xyvEyljs/ModJrpBBWTsMe2TyPVCzpfQq1XWGjWzXseUUus0y/TbW'),
(9, 'Schneider', 'Elias', 'elias.schneider@zdf.de', '$2y$12$w9g3AEVbu8lgENfuU8L30OXtAEEKlWt7p/y.HNZG.JSzjLN3XqAu2');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `flights`
--

CREATE TABLE `flights` (
  `id` int(11) NOT NULL,
  `departure` datetime NOT NULL,
  `arrival` datetime NOT NULL,
  `stopovers` int(11) NOT NULL DEFAULT 0,
  `departure_location` varchar(3) NOT NULL,
  `arrival_location` varchar(3) NOT NULL,
  `pilot_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `flights`
--

INSERT INTO `flights` (`id`, `departure`, `arrival`, `stopovers`, `departure_location`, `arrival_location`, `pilot_id`) VALUES
(1, '2021-03-04 06:00:00', '2021-03-04 12:30:00', 1, 'BRU', 'JFK', 6),
(2, '2021-03-04 08:15:00', '2021-03-04 10:00:00', 0, 'BRU', 'SXF', 1),
(3, '2021-03-14 13:25:00', '2021-03-14 14:10:00', 0, 'CDG', 'AMS', 2),
(4, '2021-04-02 14:30:00', '2021-04-02 23:00:00', 1, 'LHR', 'JFK', 6),
(5, '2021-04-25 20:00:00', '2021-04-25 21:15:00', 0, 'AMS', 'DUS', 6),
(6, '2021-04-27 11:00:00', '2021-04-27 17:20:00', 2, 'JFK', 'CDG', 3),
(7, '2021-05-10 18:20:00', '2021-05-10 19:10:00', 1, 'SXF', 'DUS', 1),
(8, '2021-05-11 19:45:00', '2021-05-11 20:50:00', 0, 'CRL', 'LHR', 2),
(9, '2021-05-12 10:00:00', '2021-05-12 11:00:00', 1, 'LCY', 'DUS', 2),
(10, '2021-05-15 04:00:00', '2021-05-15 11:00:00', 2, 'JFK', 'AMS', 6),
(11, '2021-05-17 13:30:00', '2021-05-17 14:30:00', 0, 'LCY', 'BRU', 5),
(12, '2021-05-28 06:00:00', '2021-05-28 07:15:00', 0, 'DUS', 'CRL', 1),
(13, '2021-06-12 08:50:00', '2021-06-12 15:20:00', 0, 'SXF', 'JFK', 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `pilots`
--

CREATE TABLE `pilots` (
  `id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `flying_hours` int(11) DEFAULT 0,
  `number_of_emergency_landings` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `pilots`
--

INSERT INTO `pilots` (`id`, `last_name`, `first_name`, `flying_hours`, `number_of_emergency_landings`) VALUES
(1, 'De Vriendt', 'Pieter', 3452, 4),
(2, 'Jones', 'Henry', 1463, 2),
(3, 'Legrand', 'Simon', 471, 0),
(4, 'Anderson', 'Vickie', 8947, 3),
(5, 'MÃ¼ller', 'Alexander', 3965, 1),
(6, 'Smith', 'Amanda', 2261, 2),
(7, 'Dubois', 'Martin', 6782, 0),
(8, 'Hofman', 'Daan', 1912, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `reservation_date` date NOT NULL,
  `number_of_persons` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `reservations`
--

INSERT INTO `reservations` (`id`, `reservation_date`, `number_of_persons`, `customer_id`, `flight_id`, `class_id`) VALUES
(1, '2024-02-05', 2, 1, 5, 1),
(2, '2023-02-07', 1, 6, 5, 1),
(3, '2021-02-09', 6, 8, 1, 2),
(4, '2022-02-15', 2, 2, 9, 1),
(5, '2024-03-04', 1, 7, 11, 1),
(6, '2024-03-27', 3, 5, 10, 2),
(7, '2023-04-01', 4, 3, 4, 2),
(8, '2024-04-03', 2, 6, 4, 1),
(9, '2024-04-11', 1, 1, 8, 1),
(10, '2021-04-21', 6, 2, 13, 2),
(11, '2021-05-03', 2, 3, 6, 1),
(12, '2024-05-10', 2, 6, 11, 1),
(13, '2021-05-12', 4, 4, 2, 2),
(14, '2023-05-12', 2, 9, 12, 2),
(15, '2023-05-18', 3, 5, 2, 2),
(16, '2021-05-22', 1, 1, 13, 1);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `airports`
--
ALTER TABLE `airports`
  ADD PRIMARY KEY (`id`,`country_id`),
  ADD KEY `fk_airports_countries1_idx` (`country_id`);

--
-- Indexen voor tabel `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`,`departure_location`,`arrival_location`,`pilot_id`),
  ADD KEY `fk_flights_airports1_idx` (`departure_location`),
  ADD KEY `fk_flights_airports2_idx` (`arrival_location`),
  ADD KEY `fk_flights_pilots1_idx` (`pilot_id`);

--
-- Indexen voor tabel `pilots`
--
ALTER TABLE `pilots`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`,`customer_id`,`flight_id`,`class_id`),
  ADD KEY `fk_customers_has_flights_flights1_idx` (`flight_id`),
  ADD KEY `fk_customers_has_flights_customers_idx` (`customer_id`),
  ADD KEY `fk_reservations_class1_idx` (`class_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT voor een tabel `flights`
--
ALTER TABLE `flights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT voor een tabel `pilots`
--
ALTER TABLE `pilots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `airports`
--
ALTER TABLE `airports`
  ADD CONSTRAINT `fk_airports_countries1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `flights`
--
ALTER TABLE `flights`
  ADD CONSTRAINT `fk_flights_airports1` FOREIGN KEY (`departure_location`) REFERENCES `airports` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_flights_airports2` FOREIGN KEY (`arrival_location`) REFERENCES `airports` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_flights_pilots1` FOREIGN KEY (`pilot_id`) REFERENCES `pilots` (`id`) ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_customers_has_flights_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_customers_has_flights_flights1` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_reservations_class1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
