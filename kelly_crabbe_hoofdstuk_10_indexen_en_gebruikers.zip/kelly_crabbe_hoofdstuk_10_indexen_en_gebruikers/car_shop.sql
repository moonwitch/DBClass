-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Machine: 127.0.0.1
-- Gegenereerd op: 07 dec 2021 om 21:54
-- Serverversie: 5.6.20
-- PHP-versie: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `car_shop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `brands`
--
CREATE DATABASE `car_shop`;
USE `car_shop`;

CREATE TABLE IF NOT EXISTS `brands` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Gegevens worden geëxporteerd voor tabel `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(1, 'Alfa Romeo'),
(2, 'Ford'),
(3, 'Audi'),
(4, 'BMW'),
(5, 'Chrysler'),
(6, 'Renault'),
(7, 'Mercedes-Benz'),
(8, 'Honda'),
(9, 'Skoda'),
(10, 'Nissan'),
(11, 'Volkswagen');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cars`
--

CREATE TABLE IF NOT EXISTS `cars` (
`id` int(11) NOT NULL,
  `license_plate` varchar(12) NOT NULL,
  `color` varchar(40) DEFAULT NULL,
  `model_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Gegevens worden geëxporteerd voor tabel `cars`
--

INSERT INTO `cars` (`id`, `license_plate`, `color`, `model_id`) VALUES
(1, '1-TKS-987', 'rood', 5),
(2, '1-TPQ-147', 'grijs', 2),
(3, '1-WAM-987', 'grijs', 6),
(4, '1-QMA-242', 'rood', 4),
(5, '1-WKG-837', 'blauw', 1),
(6, '1-PPX-672', 'zwart', 4),
(7, '1-MOW-276', 'grijs', 2),
(8, '1-HSX-542', 'geel', 2),
(9, '1-UOX-558', 'rood', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `tel` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Gegevens worden geëxporteerd voor tabel `customers`
--

INSERT INTO `customers` (`id`, `name`, `firstname`, `email`, `tel`) VALUES
(1, 'Peeters', 'Paul', 'paul.peeters@orange.be', '016214368'),
(2, 'Van Parys', 'Eline', 'eline1989@outlook.com', '0475671294'),
(3, 'Janssens', 'Dorien', NULL, '0439752469'),
(4, 'Van Laar', 'Anna', NULL, '0421259431'),
(5, 'Dormaals', 'Lars', 'lars_dormaals@outlook.com', '0469431685'),
(6, 'Oudheers', 'Johan', NULL, '0437136215'),
(7, 'Zeemans', 'Koen', NULL, '0452659138'),
(8, 'Vandevelde', 'Seppe', NULL, '0491259693'),
(9, 'Al-Kour', 'Mohamad', 'mahamad2000@gmail.com', '0431426728'),
(10, 'Wolfs', 'Lisa', NULL, '0435251754'),
(11, 'De Kepper', 'Mark', NULL, '0431968534'),
(12, 'Geeraerts', 'Iona', NULL, '0434886275');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `models`
--

CREATE TABLE IF NOT EXISTS `models` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `brand_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Gegevens worden geëxporteerd voor tabel `models`
--

INSERT INTO `models` (`id`, `name`, `brand_id`) VALUES
(1, 'Galaxy', 2),
(2, 'Mustang', 2),
(3, 'Edge', 2),
(4, 'Fabia', 9),
(5, 'X6', 4),
(6, 'Octavia', 9),
(7, 'Golf', 11),
(8, 'Passat', 11),
(9, 'Citan', 7),
(10, 'GLA', 7),
(11, 'Captur', 6),
(12, 'Grand Voyager', 5);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `repair_sessions`
--

CREATE TABLE IF NOT EXISTS `repair_sessions` (
`id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `grand_total` double(7,2) NOT NULL DEFAULT '0.00',
  `paid` int(11) NOT NULL DEFAULT '0',
  `repair_date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Gegevens worden geëxporteerd voor tabel `repair_sessions`
--

INSERT INTO `repair_sessions` (`id`, `customer_id`, `car_id`, `grand_total`, `paid`, `repair_date`) VALUES
(1, 5, 2, 245.00, 1, '2021-11-12'),
(2, 1, 5, 489.00, 1, '2021-11-12'),
(3, 5, 2, 421.00, 0, '2021-11-13'),
(4, 4, 3, 356.00, 1, '2021-11-14'),
(5, 3, 5, 245.00, 1, '2021-11-18'),
(6, 8, 6, 19.99, 1, '2021-11-21'),
(7, 6, 4, 1561.00, 1, '2021-11-21'),
(8, 4, 2, 78.00, 1, '2021-11-29'),
(9, 5, 1, 873.00, 0, '2021-12-01'),
(10, 3, 5, 761.00, 1, '2021-12-03'),
(11, 4, 6, 55.00, 1, '2021-12-04');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `brands`
--
ALTER TABLE `brands`
 ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `cars`
--
ALTER TABLE `cars`
 ADD PRIMARY KEY (`id`,`model_id`), ADD KEY `fk_cars_models1_idx` (`model_id`);

--
-- Indexen voor tabel `customers`
--
ALTER TABLE `customers`
 ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `models`
--
ALTER TABLE `models`
 ADD PRIMARY KEY (`id`,`brand_id`), ADD KEY `fk_models_brands_idx` (`brand_id`);

--
-- Indexen voor tabel `repair_sessions`
--
ALTER TABLE `repair_sessions`
 ADD PRIMARY KEY (`id`,`customer_id`,`car_id`), ADD KEY `fk_customers_has_cars_cars1_idx` (`car_id`), ADD KEY `fk_customers_has_cars_customers1_idx` (`customer_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `brands`
--
ALTER TABLE `brands`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT voor een tabel `cars`
--
ALTER TABLE `cars`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT voor een tabel `customers`
--
ALTER TABLE `customers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT voor een tabel `models`
--
ALTER TABLE `models`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT voor een tabel `repair_sessions`
--
ALTER TABLE `repair_sessions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `cars`
--
ALTER TABLE `cars`
ADD CONSTRAINT `fk_cars_models1` FOREIGN KEY (`model_id`) REFERENCES `models` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `models`
--
ALTER TABLE `models`
ADD CONSTRAINT `fk_models_brands` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `repair_sessions`
--
ALTER TABLE `repair_sessions`
ADD CONSTRAINT `fk_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_customers_has_cars_cars1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
