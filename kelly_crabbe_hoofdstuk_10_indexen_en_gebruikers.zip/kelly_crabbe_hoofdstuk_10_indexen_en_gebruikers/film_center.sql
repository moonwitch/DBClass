-- Database export via SQLPro (https://www.sqlprostudio.com/)
-- Exported by kellyc at 12-01-2025 20:26.
-- WARNING: This file may contain descructive statements such as DROPs.
-- Please ensure that you are running the script at the proper location.


-- BEGIN TABLE employees
DROP TABLE IF EXISTS employees;
CREATE TABLE `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `date_of_birth` varchar(45) DEFAULT NULL,
  `estimated_net_worth` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`first_name`,`last_name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;

-- Inserting 20 rows into employees
-- Insert batch #1
INSERT INTO employees (id, first_name, last_name, date_of_birth, estimated_net_worth) VALUES
(1, 'Mark', 'Hamill', '1951-09-25', 18000000),
(2, 'Marlon', 'Brando', '1924-04-03', 100000000),
(3, 'Steven', 'Spielberg', '1946-12-18', 4800000000),
(4, 'Cillian', 'Murphy', '1976-05-25', 20000000),
(5, 'George', 'Lucas', '1944-05-14', 5000000000),
(6, 'Tom', 'Hanks', '1956-07-09', 400000000),
(7, 'Harrison', 'Ford', '1942-07-13', 300000000),
(8, 'Sam', 'Neil', '1947-09-14', 18000000),
(9, 'Janusz', 'Kamiński', '1959-06-27', NULL),
(20, ' Tom', ' Cruise', ' 1962-07-03', NULL),
(21, ' Robbie', ' Coltrane', ' 1950-03-30', NULL),
(22, ' Joaquin', ' Phoenix', ' 1974-10-28', 60000000),
(23, ' Mel', ' Gibson', ' 1956-01-03', NULL),
(24, ' Bradley', ' Cooper', ' 1975-01-05', NULL),
(25, ' Robert', ' Duvall', ' 1931-01-05', NULL),
(26, ' Rowan', ' Atkinson', ' 1955-01-06', NULL),
(27, ' Warwick', ' Davis', ' 1970-02-03', NULL),
(28, ' Lupita', ' Nyong''o', ' 1983-03-01', NULL),
(29, ' Dustin', ' Hoffman', ' 1937-08-08', 100000000),
(30, ' Keira', ' Knightley', ' 1985-03-26', NULL);

-- END TABLE employees

-- BEGIN TABLE employment_contracts
DROP TABLE IF EXISTS employment_contracts;
CREATE TABLE `employment_contracts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `film` int NOT NULL,
  `employee` int NOT NULL,
  `role` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`,`film`,`employee`,`role`),
  KEY `fk_films_has_actors_films_idx` (`film`),
  KEY `fk_employment_contracts_roles1_idx` (`role`),
  KEY `fk_employment_contracts_employees1_idx` (`employee`),
  CONSTRAINT `fk_employment_contracts_employees1` FOREIGN KEY (`employee`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_employment_contracts_roles1` FOREIGN KEY (`role`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_films_has_actors_films` FOREIGN KEY (`film`) REFERENCES `films` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- Inserting 10 rows into employment_contracts
-- Insert batch #1
INSERT INTO employment_contracts (id, film, employee, role, start_date, end_date) VALUES
(1, 2, 3, 2, '1974-04-09', '1975-01-01'),
(2, 3, 5, 2, '1975-03-05', '1977-05-25'),
(3, 3, 5, 7, '1974-06-05', '1977-05-25'),
(4, 3, 7, 1, '1975-03-05', '1977-05-25'),
(5, 3, 1, 1, '1975-03-05', '1977-05-25'),
(6, 5, 3, 2, '1992-04-12', '1993-06-09'),
(7, 4, 3, 2, '1992-07-15', '1993-11-30'),
(8, 5, 6, 1, '1992-04-19', '1993-06-09'),
(9, 4, 9, 6, '1992-07-15', '1993-11-30'),
(10, 7, 4, 1, '2022-02-01', '2023-07-11');

-- END TABLE employment_contracts

-- BEGIN TABLE films
DROP TABLE IF EXISTS films;
CREATE TABLE `films` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `budget` bigint NOT NULL,
  `box_office` bigint DEFAULT NULL,
  `running_time_in_minutes` int DEFAULT NULL,
  `original_language` int DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_films_languages1_idx` (`original_language`),
  CONSTRAINT `fk_films_languages1` FOREIGN KEY (`original_language`) REFERENCES `languages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;

-- Inserting 9 rows into films
-- Insert batch #1
INSERT INTO films (id, title, budget, box_office, running_time_in_minutes, original_language, rating, release_date) VALUES
(1, 'The godfather', 7200000, 291000000, 175, 1, 9.2, '1972-03-24'),
(2, 'Jaws', 9000000, 476500000, 124, 1, 8.1, '1975-06-20'),
(3, 'Star Wars: Episode IV: A New Hope', 11000000, 775800000, 121, 1, 8.6, '1977-05-25'),
(4, 'Schindler''s List', 22000000, 322000000, 195, 1, 9, '1993-11-30'),
(5, 'Jurassic Park', 63000000, 1000000000, 127, 1, 8.2, '1993-06-09'),
(6, 'Forrest Gump', 55000000, 678200000, 142, 1, 8.8, '1994-07-06'),
(7, 'Oppenheimer', 100000000, 942200000, 180, 1, 8.5, '2023-07-21'),
(8, 'La vita e bella', 15000000, 230000000, 116, 6, 8.6, '1997-12-20'),
(9, 'Dune: Part Two', 122000000, NULL, NULL, 2, NULL, '2024-03-15');

-- END TABLE films

-- BEGIN TABLE languages
DROP TABLE IF EXISTS languages;
CREATE TABLE `languages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- Inserting 10 rows into languages
-- Insert batch #1
INSERT INTO languages (id, name) VALUES
(1, 'Engels'),
(2, 'Spaans'),
(3, 'Frans'),
(4, 'Duits'),
(5, 'Japans'),
(6, 'Italiaans'),
(7, 'Azerbeidzjaans'),
(8, 'Oekraïens'),
(9, 'Perzisch'),
(10, 'Chinees');

-- END TABLE languages

-- BEGIN TABLE roles
DROP TABLE IF EXISTS roles;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

-- Inserting 7 rows into roles
-- Insert batch #1
INSERT INTO roles (id, name) VALUES
(1, 'acteur'),
(2, 'regisseur'),
(3, 'producent'),
(4, 'productie assistent'),
(5, 'componist'),
(6, 'cinematograaf'),
(7, 'scenarioschrijver');

-- END TABLE roles

