<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (empty(trim($_POST["role"])) || empty(trim($_POST["description"]))) {
            echo "Please fill in all fields.";
        } else {
            $db_host = "127.0.0.1";
            $db_name = "digitech";
            $db_user = "root";
            $db_pass = "";
            $db_port = "3306";

            $db_conn = new PDO("mysql:host=$db_host;dbname=$db_name;port=$db_port", $db_user, $db_pass);
            $query = "INSERT INTO `roles` (`name`, `description`) VALUES (:name, :description)";

            $add_role = $db_conn->prepare($query);
            $add_role -> bindValue(':name', $_POST["role"]);
            $add_role -> bindValue(':description', $_POST["description"]);
            $add_role -> execute();

            echo "Role added successfully.";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nieuwe rol toevoegene</title>
</head>

<body>
    <form method="POST" action="add_role.php">
        <label for="role">Rol naam:</label>
        <input type="text" id="role" name="role"><br>
        <label for="description">Beschrijving:</label>
        <input type="text" id="description" name="description"><br>
        <input type="submit" value="Toevoegen">
    </form>
</body>

</html>