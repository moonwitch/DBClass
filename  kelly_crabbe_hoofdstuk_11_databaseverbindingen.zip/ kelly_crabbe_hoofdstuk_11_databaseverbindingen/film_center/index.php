<?php
// Databasegegevens
$db_host = "127.0.0.1"; // Gebruik 127.0.0.1 om TCP/IP-verbinding te forceren
$db_name = "film_center";
$db_user = "root";
$db_pass = "";
$db_port = "3306";

try {
    // Maak verbinding met de database
    $db_conn = new PDO("mysql:host=$db_host;dbname=$db_name;port=$db_port", $db_user, $db_pass);

    // Query om films op te halen die minder dan 3 uur duren
    $query = "SELECT id, title, rating, release_date 
              FROM films 
              WHERE running_time_in_minutes < 180";

    // Voer de query uit
    $result = $db_conn->query($query);

    // Controleer of er records zijn opgehaald
    if ($result->rowCount() > 0) {
        // Begin van de tabel
        echo "<table style='border-collapse: collapse; width: 100%;'>";

        // Tabelkop
        echo "<tr>
                <th style='text-align: left;'>id</th>
                <th style='text-align: left;'>titel</th>
                <th style='text-align: left;'>score</th>
                <th style='text-align: left;'>releasedatum</th>
            </tr>";

        // Tabelrijen
        foreach ($result as $row) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['id']) . "</td>
                    <td>" . htmlspecialchars($row['title']) . "</td>
                    <td>" . htmlspecialchars($row['rating']) . "</td>
                    <td>" . htmlspecialchars($row['release_date']) . "</td>
                </tr>";
        }

        // Sluit de tabel
        echo "</table>";
    } else {
        // Geen gegevens gevonden
        echo "Er konden geen gegevens worden opgehaald.";
    }
} catch (PDOException $e) {
    // Foutmelding weergeven (Copilot is dus wel nuttig)
    echo "Fout: " . $e->getMessage();
}

?>