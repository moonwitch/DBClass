<?php
// Databasegegevens
$db_host = "127.0.0.1";
$db_name = "film_center";
$db_user = "root";
$db_pass = "";
$db_port = "3306";

// Variabele voor foutmeldingen en succesberichten
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Controleer of de verplichte velden zijn ingevuld
    if (
        empty($_POST['first_name']) ||
        empty($_POST['last_name']) ||
        empty($_POST['date_of_birth'])
    ) {
        $message = "Velden voor voornaam, achternaam en geboortedatum zijn verplicht.";
    } else {
        // Verkrijg ingevoerde gegevens
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $date_of_birth = $_POST['date_of_birth'];
        $estimated_net_worth = !empty($_POST['estimated_net_worth']) ? $_POST['estimated_net_worth'] : null;

        // Maak verbinding met de database
        $db_conn = new PDO("mysql:host=$db_host;dbname=$db_name;port=$db_port", $db_user, $db_pass);

        // Bereid de query voor
        $query = "INSERT INTO employees (first_name, last_name, date_of_birth, estimated_net_worth) 
                  VALUES (:first_name, :last_name, :date_of_birth, :estimated_net_worth)";
        $stmt = $db_conn->prepare($query);

        // Bind parameters
        $stmt->bindParam(':first_name', $first_name);
        $stmt->bindParam(':last_name', $last_name);
        $stmt->bindParam(':date_of_birth', $date_of_birth);
        $stmt->bindParam(':estimated_net_worth', $estimated_net_worth);

        // Voer de query uit
        $stmt->execute();

        $message = "De nieuwe werknemer is succesvol toegevoegd.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nieuwe Werknemer Toevoegen</title>
</head>

<body>
    <h1>Nieuwe Werknemer Toevoegen</h1>

    <!-- Toon fout- of succesbericht -->
    <?php if (!empty($message)): ?>
        <p style="color: red;"><?= $message ?></p>
    <?php endif; ?>

    <form action="<?= $_SERVER["PHP_SELF"] ?>" method="post">
        <label for="first_name">Voornaam:</label>
        <input type="text" id="first_name" name="first_name" required><br><br>

        <label for="last_name">Achternaam:</label>
        <input type="text" id="last_name" name="last_name" required><br><br>

        <label for="date_of_birth">Geboortedatum:</label>
        <input type="date" id="date_of_birth" name="date_of_birth" required><br><br>

        <label for="estimated_net_worth">Geschat Vermogen:</label>
        <input type="number" id="estimated_net_worth" name="estimated_net_worth" step="1000000" placeholder="Optioneel"><br><br>

        <button type="submit">Toevoegen</button>
    </form>
</body>

</html>