<?php
    $db_host = "127.0.0.1";
    $db_name = "digitech";
    $db_user = "root";
    $db_pass = "";
    $db_port = "3306";

    $db_conn = new PDO("mysql:host=$db_host;dbname=$db_name;port=$db_port", $db_user, $db_pass);
    $query = "SELECT `id`, `first_name`, `last_name` FROM `employees`";
    $result = $db_conn->prepare($query);
    $result->execute();

    $num_employees = $result->rowCount();

    //echo $num_employees . " employees found in the database.<br>";

    if ($num_employees ==0) {
        echo "No employees found in the database.<br>";
    } else {
        $result -> setFetchMode(PDO::FETCH_ASSOC); // set the resulting array to associative
        $employees = $result->fetchAll();
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>First Name</th><th>Last Name</th></tr>";

        foreach ($employees as $employee) {
            echo "<tr>";
            echo "<td>" . $employee['id'] . "</td>";
            echo "<td>" . $employee['first_name'] . "</td>";
            echo "<td>" . $employee['last_name'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
?>