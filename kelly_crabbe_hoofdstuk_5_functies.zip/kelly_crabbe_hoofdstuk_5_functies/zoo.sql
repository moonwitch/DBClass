USE `zoo`;
SELECT MAX(`weight`) FROM `animals`;